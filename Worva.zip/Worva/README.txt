~~ Sha's Worva ~~

*Desc*
I made Wordle in Java cuz I was bored so if you wanna play a worse version of someone else's game, here ya go!
Orginal game: https://www.nytimes.com/games/wordle/index.html

*How to play*
Try to guess the five letter word! You get six guesses and each guess is evaluated.
 - If a letter of the word is in the right place, a 'O' or '🟩' will appear above the lettter.
 - If a letter is in the word, but not in the right place, a '!' or '🟨' will appear above the letter.
 - If a letter is not in the word, a 'X' or '⬛' will appear above the letter. If you enter a word shorter or longer than 5 letters, your entry will not be taken and you will have to type your guess again.

*Limitations*
 - There is no spell check so you can definitly cheese the game by just typing gibberish.
 - Looks kinda gross without the unicode characters (colored boxes) so I hope you have a terminal that supports them lol!
 - The word is picked at random from a list so I guess you could get duplicates after a while.